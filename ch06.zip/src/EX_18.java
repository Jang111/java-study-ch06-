class EX_18{
	public static void main(String[] args) {
		int x=2;
		int n=5;
		long result=0;
		EX_18 m = new EX_18();
		for(int i=1;i<=n;i++) {
			result+=m.power(x,i);
		}
		System.out.println(result);
	}
	long power(int x,int n) {
		if(n==1) return x;
		return x*power(x,n-1);
	}
}
