class EX_21{
	public static void main(String[] args) {
		Data1 d1=new Data1();
		Data2 d2 = new Data2(5);
		d1.value=10;
		System.out.printf("d1.value=%d%n",d1.value);
		System.out.printf("d2.value=%d",d2.value);
	}
}

class Data1{
	int value;
	Data1(){}//�⺻ ������(default constructor)=>���ִ� ���� ����!!
}
class Data2{
	int value;
	
	Data2(int x){
		value=x;
	}
}
