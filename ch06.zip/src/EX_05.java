class EX_05{
	public static void main(String[] args) {
		System.out.println("Card.width = "+Card.width);
		System.out.println("Card.height = "+Card.height);
		
		Card c1 = new Card();
		c1.Kind = new String("Heart");
		c1.number = 7;
		
		Card c2 = new Card();
		c2.Kind = new String("Spade");
		c2.number = 4;
		
		System.out.println("c1�� "+c1.Kind+", "+c1.number+
				"�̸�, ũ��� ("+Card.width+", "+Card.height+")");
		System.out.println("c2�� "+c2.Kind+", "+c2.number+
				"�̸�, ũ��� ("+Card.width+", "+Card.height+")");
		System.out.println("c1�� width�� height�� ���� 50,80���� �����մϴ�.");
		Card.width=50;
		Card.height=80;
		System.out.println("c1�� "+c1.Kind+", "+c1.number+
				"�̸�, ũ��� ("+Card.width+", "+Card.height+")");
		System.out.println("c2�� "+c2.Kind+", "+c2.number+
				"�̸�, ũ��� ("+Card.width+", "+Card.height+")");
		}
}
class Card{
	String Kind;
	int number;
	static int width = 100;
	static int height = 250;
}