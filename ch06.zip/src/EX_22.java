class EX_22{
	public static void main(String[] args) {
		Car c1 = new Car();
		c1.Color=new String("white");
		c1.gearType = new String("auto");
		c1.door = 4;
		
		Car c2 = new Car("white","auto",4);
		
		System.out.println("c1�� color="+c1.Color+", gearType="
				+c1.gearType+", door="+c1.door);
		System.out.println("c2�� color="+c2.Color+", gearType="
				+c2.gearType+", door="+c2.door);
		
	}
}
class Car{
	String Color;
	String gearType;
	int door;
    
	Car(){}
	Car(String c, String g,int d){
		Color=c;
		gearType=g;
		door = d;
		
	}
}

