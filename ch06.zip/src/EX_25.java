class EX_25{
	static {
		System.out.println("static { }");
	}
	{
		System.out.println("{ }");
	}
	public EX_25() {
		System.out.println("������");
	}
	public static void main(String[] args) {
		System.out.println("EX_25 bt = new EX_25();");
		EX_25 bt = new EX_25();
		
		System.out.println("EX_25 bt2 = new EX_25();");
		EX_25 bt2 = new EX_25();
	}
}
